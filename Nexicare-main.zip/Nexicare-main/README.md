# Nexicare
Hospisoft Labs, Mobile app project
Java && build.gradle


### App Preview :

<div align="center">
<img width="60%" src="RESOURCES/Home.png"/>
</div>

#

## Authentication Pages

<div align="center">
<img width="60%" src="RESOURCES/Login.png"/>
<img width="60%" src="RESOURCES/Register.png"/>
</div>

#
